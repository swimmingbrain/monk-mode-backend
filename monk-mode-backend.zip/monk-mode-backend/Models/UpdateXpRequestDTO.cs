﻿namespace monk_mode_backend.Models {
    public class UpdateXpRequestDTO {
        public int XpToAdd { get; set; }
    }
}
