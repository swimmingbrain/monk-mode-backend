﻿namespace monk_mode_backend.Models {
    public class ResponseDTO {
        public string Status { get; set; }
        public string Message { get; set; }
    }
}
